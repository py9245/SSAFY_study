# print("hello world")
# print(-2 ** 4)
# number = 10
# double = number * 2
# print(double)

# number = 5
# double = number * 2
# print(double)

a = 1
b = 1.0
print(a == b)