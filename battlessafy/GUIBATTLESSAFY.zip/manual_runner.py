import sys
from collections import deque
import heapq

##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]  # 맵 정보
my_allies = {}  # 아군 정보
enemies = {}  # 적군 정보
codes = []  # 암호문
game_data_str = "" # 원본 데이터 문자열 저장용

##############################
# 입력 데이터 파싱
##############################

def parse_data(game_data):
    global map_data, my_allies, enemies, codes, game_data_str
    game_data_str = game_data # 원본 저장

    game_data_rows = game_data.split('\n')
    row_index = 0

    try:
        header = game_data_rows[row_index].split(' ')
        map_height = int(header[0]) if len(header) >= 1 else 0
        map_width = int(header[1]) if len(header) >= 2 else 0
        num_of_allies = int(header[2]) if len(header) >= 3 else 0
        num_of_enemies = int(header[3]) if len(header) >= 4 else 0
        num_of_codes = int(header[4]) if len(header) >= 5 else 0
        row_index += 1

        map_data.clear()
        map_data.extend([['' for _ in range(map_width)] for _ in range(map_height)])
        for i in range(map_height):
            col = game_data_rows[row_index + i].split(' ')
            for j in range(len(col)):
                map_data[i][j] = col[j]
        row_index += map_height

        my_allies.clear()
        for i in range(row_index, row_index + num_of_allies):
            ally = game_data_rows[i].split(' ')
            ally_name = ally.pop(0) if len(ally) >= 1 else '-'
            my_allies[ally_name] = ally
        row_index += num_of_allies

        enemies.clear()
        for i in range(row_index, row_index + num_of_enemies):
            enemy = game_data_rows[i].split(' ')
            enemy_name = enemy.pop(0) if len(enemy) >= 1 else '-'
            enemies[enemy_name] = enemy
        row_index += num_of_enemies

        codes.clear()
        for i in range(row_index, row_index + num_of_codes):
            codes.append(game_data_rows[i])
    except (ValueError, IndexError) as e:
        print(f"Error parsing data: {e}")
        # Initialize with empty values to prevent crashes
        map_data, my_allies, enemies, codes = [[]], {}, {}, []


def print_data():
    print(f'\n----------입력 데이터----------\n{game_data_str}\n----------------------------')
    if not map_data or not map_data[0]:
        print(f'\n[맵 정보] (0 x 0)')
        return

    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (적군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (적군 탱크) - 체력: {v[0]}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])

def read_state_from_stdin(prompt=""):
    if prompt:
        print(f"\n{prompt}", flush=True)
    lines = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip().upper() == "END":
            break
        lines.append(line)
    return "\n".join(lines).strip() or None

###################################
# 알고리즘 함수/메서드 부분 구현 시작
###################################

DIRS = [(0,1), (1,0), (0,-1), (-1,0)]
MOVE_CMDS = {0: "R A", 1: "D A", 2: "L A", 3: "U A"}
FIRE_CMDS = {0: "R F", 1: "D F", 2: "L F", 3: "U F"}
START_SYMBOL = 'M'
TARGET_SYMBOL = 'X'
IMPASSABLE = {'R','W','F','H'}

def in_range(r,c,h,w): return 0 <= r < h and 0 <= c < w

def find_cell(grid, symbol):
    if not grid or not grid[0]: return None
    h, w = len(grid), len(grid[0])
    for r in range(h):
        for c in range(w):
            if grid[r][c] == symbol:
                return (r,c)
    return None

def cell_cost(sym, big_cost):
    if sym == 'G': return 1
    if sym == 'T': return big_cost
    return None

def reconstruct_path(prev, end_rc):
    path_dirs = []
    cells = []
    r, c = end_rc
    while prev[r][c] is not None:
        pr, pc, di = prev[r][c]
        path_dirs.append(di)
        cells.append((r,c))
        r, c = pr, pc
    cells.append((r,c))
    path_dirs.reverse()
    cells.reverse()
    return path_dirs, cells

def dijkstra_to_adjacent_of_target(grid, start, target_pos):
    h, w = len(grid), len(grid[0])
    tr, tc = target_pos
    
    # 1. 사거리 3, 물 통과 규칙을 적용하여 모든 발사 가능 지점 탐색
    PROJECTILE_PASSABLE = {'G', 'T', 'W', '0'}
    firing_candidates = {} # Key: (r,c) 발사 위치, Value: fire_dir_idx 발사 방향

    for fire_dir_idx, (dr, dc) in enumerate(DIRS):
        # 목표물(X)에서부터 바깥쪽으로 3칸까지 탐색
        for i in range(1, 3 + 1):
            fr, fc = tr - dr*i, tc - dc*i # 발사 예상 위치

            if not in_range(fr, fc, h, w): break # 맵 밖

            # 서 있을 수 있는 타일인지 확인 (G 또는 T)
            if grid[fr][fc] not in {'G', 'T'}: continue

            # 발사 위치와 목표물 사이의 경로가 깨끗한지 확인
            path_is_clear = True
            for j in range(1, i):
                path_r, path_c = fr + dr*j, fc + dc*j
                if grid[path_r][path_c] not in PROJECTILE_PASSABLE:
                    path_is_clear = False
                    break
            
            if path_is_clear:
                # 같은 위치라도 다른 방향에서 쏠 수 있으므로, 첫 발견만 기록 (더 가까운 쪽)
                if (fr, fc) not in firing_candidates:
                    firing_candidates[(fr, fc)] = fire_dir_idx
    
    if not firing_candidates:
        return None # 발사 가능 위치 없음

    # 2. 시작점에서부터 모든 발사 가능 지점까지 다익스트라 실행
    big = h*w
    sr, sc = start
    
    INF = 10**18
    dist = [[INF]*w for _ in range(h)]
    prev = [[None]*w for _ in range(h)]
    pq = []

    dist[sr][sc] = 0
    heapq.heappush(pq,(0,sr,sc))

    while pq:
        d,r,c = heapq.heappop(pq)
        if d != dist[r][c]: continue

        # 발사 가능 지점에 도달했는지 확인
        if (r,c) in firing_candidates:
            fire_dir = firing_candidates[(r,c)]
            path_dirs, path_cells = reconstruct_path(prev,(r,c))
            return (path_dirs, path_cells, d, fire_dir) # 경로, 비용, 발사방향 반환

        # 다익스트라 확장
        for di,(dr_move,dc_move) in enumerate(DIRS):
            nr, nc = r+dr_move, c+dc_move
            if not in_range(nr,nc,h,w): continue
            sym = grid[nr][nc]
            if sym in IMPASSABLE or sym == TARGET_SYMBOL: continue
            step = cell_cost(sym, big)
            if step is None: continue
            nd = d + step
            if nd < dist[nr][nc]:
                dist[nr][nc] = nd
                prev[nr][nc] = (r,c,di)
                heapq.heappush(pq,(nd,nr,nc))

    return None # 발사 가능 위치까지 경로 없음
    return None

def first_T_in_path(path_cells):
    for (r,c) in path_cells[1:]:
        if map_data[r][c] == 'T':
            return (r,c)
    return None

def dijkstra_to_cell(grid, start, goal_cell):
    h, w = len(grid), len(grid[0])
    big = h*w
    sr, sc = start
    gr, gc = goal_cell

    INF = 10**18
    dist = [[INF]*w for _ in range(h)]
    prev = [[None]*w for _ in range(h)]
    pq = []

    dist[sr][sc] = 0
    heapq.heappush(pq,(0,sr,sc))

    while pq:
        d,r,c = heapq.heappop(pq)
        if d != dist[r][c]: continue
        if (r,c) == (gr,gc):
            path_dirs, path_cells = reconstruct_path(prev,(r,c))
            return (path_dirs, path_cells, d)

        for di,(dr,dc) in enumerate(DIRS):
            nr, nc = r+dr, c+dc
            if not in_range(nr,nc,h,w): continue
            sym = grid[nr][nc]
            if sym in IMPASSABLE or sym == TARGET_SYMBOL:
                continue
            step = cell_cost(sym, big)
            if step is None:
                continue
            nd = d + step
            if nd < dist[nr][nc]:
                dist[nr][nc] = nd
                prev[nr][nc] = (r,c,di)
                heapq.heappush(pq,(nd,nr,nc))
    return None

def build_actions_from_dirs(path_dirs):
    return [MOVE_CMDS[d] for d in path_dirs]

def get_initial_actions():
    start = find_cell(map_data, START_SYMBOL)
    target = find_cell(map_data, TARGET_SYMBOL)
    if not start or not target:
        print("[ERROR] Start or target not found in map")
        return []

    res = dijkstra_to_adjacent_of_target(map_data, start, target)
    if res is None:
        return []

    path_dirs, path_cells, total_cost, fire_dir = res
    big = len(map_data)*len(map_data[0]) if map_data and map_data[0] else 1
    if total_cost <= big:
        fire_cmd = None
        # Target is 'X', prioritize mega bomb
        if TARGET_SYMBOL == 'X':
            # Check for mega bombs
            if 'M' in my_allies and len(my_allies['M']) > 3 and int(my_allies['M'][3]) > 0:
                fire_cmd = FIRE_CMDS[fire_dir] + " M"
            # Else, check for normal bombs
            elif 'M' in my_allies and len(my_allies['M']) > 2 and int(my_allies['M'][2]) > 0:
                fire_cmd = FIRE_CMDS[fire_dir]
        
        if fire_cmd:
            return build_actions_from_dirs(path_dirs) + [fire_cmd]
        else: # No bombs
            return build_actions_from_dirs(path_dirs)

    else:
        first_t = first_T_in_path(path_cells)
        if first_t is not None:
            res2 = dijkstra_to_cell(map_data, start, first_t)
            if res2 is not None:
                path_dirs2, _, _ = res2
                return build_actions_from_dirs(path_dirs2)
        return build_actions_from_dirs(path_dirs)

###################################
# GUI 시뮬레이션용 함수
###################################

def get_state_string():
    """Constructs the state string from current global variables."""
    if not map_data or not map_data[0]:
        return ""
        
    header = f"{len(map_data)} {len(map_data[0])} {len(my_allies)} {len(enemies)} {len(codes)}"
    
    map_str = "\n".join(" ".join(row) for row in map_data)
    
    allies_str = "\n".join(f"{name} {' '.join(stats)}" for name, stats in my_allies.items())
    
    enemies_str = "\n".join(f"{name} {' '.join(stats)}" for name, stats in enemies.items())
    
    codes_str = "\n".join(codes)
    
    parts = [header, map_str, allies_str, enemies_str, codes_str]
    return "\n".join(p for p in parts if p)

def apply_action(command: str):
    """Simulates the effect of a command on the current state."""
    global map_data, my_allies, enemies
    
    start_pos = find_cell(map_data, START_SYMBOL)
    if not start_pos: return

    r, c = start_pos
    
    parts = command.split(' ')
    if len(parts) == 0:
        return # Invalid command
    
    direction = parts[0]
    action = ""
    if len(parts) > 1:
        action = parts[1]

    dir_map = {'R': 0, 'D': 1, 'L': 2, 'U': 3}
    if direction not in dir_map: return

    d = dir_map[direction]
    dr, dc = DIRS[d]

    # Update tank direction
    if 'M' in my_allies and len(my_allies['M']) > 1:
        my_allies['M'][1] = direction

    if action == 'A': # Move
        nr, nc = r + dr, c + dc
        
        if in_range(nr, nc, len(map_data), len(map_data[0])) and map_data[nr][nc] not in ['R', 'W', 'H', 'X', 'F']:
            map_data[r][c] = 'G' # Clear old position, 'G' for grass
            map_data[nr][nc] = START_SYMBOL # Move to new position
    
    elif action == 'F': # Fire (covers F and F M)
        PROJECTILE_BLOCKERS = {'R', 'H'} # 포탄을 막는 지형

        # 사거리 3칸 적용
        for i in range(1, 3 + 1):
            nr, nc = r + dr*i, c + dc*i

            if not in_range(nr, nc, len(map_data), len(map_data[0])):
                break # 맵 밖으로 나가면 중단

            target_symbol = map_data[nr][nc]

            # 적을 맞췄을 경우
            if target_symbol in enemies:
                del enemies[target_symbol]
                map_data[nr][nc] = 'G' # 파괴된 자리는 잔디로 변경
                print(f"[SIM] Fired at {target_symbol} and destroyed it.")
                break # 포탄 소멸

            # 포탄이 장애물에 막혔을 경우
            if target_symbol in PROJECTILE_BLOCKERS:
                break # 포탄 소멸


###################################
# 메인 로직 (콘솔 실행용)
###################################
def main():
    game_data = read_state_from_stdin("첫 상태를 붙여넣고 마지막 줄에 END만 입력하세요:")
    if not game_data:
        return

    parse_data(game_data)
    actions = get_initial_actions()

    while game_data is not None:
        print_data()

        if not actions:
            actions = get_initial_actions()

        if not actions:
            output = 'A' # Fallback action
        else:
            output = actions.pop(0)
            
            if output.endswith(' A'):
                start_pos = find_cell(map_data, START_SYMBOL)
                if start_pos:
                    r, c = start_pos
                    direction = output.split(' ')[0]
                    
                    dir_map = {'R': 0, 'D': 1, 'L': 2, 'U': 3}
                    if direction in dir_map:
                        d = dir_map[direction]
                        dr, dc = DIRS[d]
                        nr, nc = r + dr, c + dc

                        if in_range(nr, nc, len(map_data), len(map_data[0])) and map_data[nr][nc] == 'T':
                            # Target is 'T', prioritize normal bomb
                            fire_cmd = None
                            # Check for normal bombs
                            if 'M' in my_allies and len(my_allies['M']) > 2 and int(my_allies['M'][2]) > 0:
                                fire_cmd = f"{direction} F"
                            # Else, check for mega bombs
                            elif 'M' in my_allies and len(my_allies['M']) > 3 and int(my_allies['M'][3]) > 0:
                                fire_cmd = f"{direction} F M"
                            
                            if fire_cmd:
                                output = fire_cmd

        print(f"\n[OUTPUT] {output}")

        game_data = read_state_from_stdin("다음 상태를 붙여넣고 END (종료하려면 빈 입력):")
        if not game_data:
            break
        
        parse_data(game_data)

if __name__ == "__main__":
    main()