압축해제 후 현재 폴더에서 vscode, 파이참 등 실행 시킨 후
pip install pyinstaller
pyinstaller --onefile --windowed --name BattleSsafyRunner gui_runner.py
python gui_runner.py

순차적으로 입력 시
GUI프로그램 열림

아래의 입력 예시를 예로 삼아 바꿔가며 실행시켜보세요

*똑같은 기능을 하는 월요일 평가용 코드는 main.py입니다 분석해보세요*

입력예시)
---------------------------
10 10 1 1 0
G G T W G T T W W X
G G W W G T T W W W
G G W W G T T W W W
G G T G G T T G G G
G G W G G G T T W W
G G W G G G G G W W
G G W G G G W W W W
G G W T T T T T T G
G G W T T T T G G G
M G G G G G G G G G
M 100 R 2 1
X 10
END
------------------------------