import tkinter as tk
from tkinter import scrolledtext, font
from manual_runner import *

class ManualRunnerGUI:
    """
    A GUI wrapper for the manual_runner.py script.
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Battle Ssafy - Manual Runner")
        self.root.geometry("900x500")

        # --- Main Frames ---
        input_frame = tk.Frame(root, padx=10, pady=10)
        input_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        output_frame = tk.Frame(root, padx=10, pady=10)
        output_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # --- Input Widgets (Left) ---
        tk.Label(input_frame, text="게임 상태 입력 (END 생략 가능):").pack(anchor='w')
        self.state_input_text = scrolledtext.ScrolledText(input_frame, height=15, width=45, wrap=tk.WORD)
        self.state_input_text.pack(fill=tk.BOTH, expand=True)
        self.state_input_text.insert(tk.END, "여기에 상태를 붙여넣으세요...")
        self.state_input_text.bind("<FocusIn>", self.clear_placeholder)
        self.state_input_text.bind("<FocusOut>", self.add_placeholder)

        self.process_button = tk.Button(input_frame, text="명령 생성", command=self.process_state, height=2)
        self.process_button.pack(pady=10, fill=tk.X)

        # --- Output Widgets (Right) ---
        tk.Label(output_frame, text="명령 결과:").pack(anchor='w')
        bold_font = font.Font(family="Courier", size=12, weight="bold")
        self.command_output_label = tk.Label(output_frame, text="-", font=bold_font, bg="lightgrey", anchor='w', justify=tk.LEFT, padx=5)
        self.command_output_label.pack(fill=tk.X, pady=(0, 10))

        tk.Label(output_frame, text="파싱된 정보:").pack(anchor='w')
        self.info_output_text = scrolledtext.ScrolledText(output_frame, height=15, width=55, wrap=tk.WORD, state='disabled')
        self.info_output_text.pack(fill=tk.BOTH, expand=True)

        self.actions = []

    def apply_action(self, command: str):
        """Simulates the effect of a command on the current state."""
        # This is a modified version for the GUI to handle tree destruction visually.
        global map_data, my_allies, enemies
        
        start_pos = find_cell(map_data, START_SYMBOL)
        if not start_pos: return

        r, c = start_pos
        
        parts = command.split(' ')
        if len(parts) == 0:
            return # Invalid command
        
        direction = parts[0]
        action = ""
        if len(parts) > 1:
            action = parts[1]

        dir_map = {'R': 0, 'D': 1, 'L': 2, 'U': 3}
        if direction not in dir_map: return

        d = dir_map[direction]
        dr, dc = DIRS[d]

        # Update tank direction
        if 'M' in my_allies and len(my_allies['M']) > 1:
            my_allies['M'][1] = direction

        if action == 'A': # Move
            nr, nc = r + dr, c + dc
            
            if in_range(nr, nc, len(map_data), len(map_data[0])) and map_data[nr][nc] not in ['R', 'W', 'H', 'X', 'F']:
                map_data[r][c] = 'G' # Clear old position, 'G' for grass
                map_data[nr][nc] = START_SYMBOL # Move to new position
        
        elif action == 'F': # Fire (covers F and F M)
            PROJECTILE_BLOCKERS = {'R', 'H'} # 포탄을 막는 지형

            # 사거리 3칸 적용
            for i in range(1, 3 + 1):
                nr, nc = r + dr*i, c + dc*i

                if not in_range(nr, nc, len(map_data), len(map_data[0])):
                    break # 맵 밖으로 나가면 중단

                target_symbol = map_data[nr][nc]

                # 나무를 맞췄을 경우
                if target_symbol == 'T':
                    map_data[nr][nc] = 'G'
                    break

                # 적을 맞췄을 경우
                if target_symbol in enemies:
                    # del enemies[target_symbol] # This is a simplification for GUI
                    map_data[nr][nc] = 'G' # 파괴된 자리는 잔디로 변경
                    break # 포탄 소멸

                # 포탄이 장애물에 막혔을 경우
                if target_symbol in PROJECTILE_BLOCKERS:
                    break # 포탄 소멸
    
    def clear_placeholder(self, event):
        if self.state_input_text.get("1.0", tk.END).strip() == "여기에 상태를 붙여넣으세요...":
            self.state_input_text.delete("1.0", tk.END)

    def add_placeholder(self, event):
        if not self.state_input_text.get("1.0", tk.END).strip():
            self.state_input_text.insert("1.0", "여기에 상태를 붙여넣으세요...")

    def process_state(self):
        state_text = self.state_input_text.get("1.0", tk.END).strip()
        if not state_text or state_text == "여기에 상태를 붙여넣으세요...":
            self.command_output_label.config(text="[오류] 상태를 입력하세요.")
            return

        if not state_text.strip().endswith("END"):
            state_text += "\nEND"

        try:
            parse_data(state_text)
        except Exception as e:
            self.command_output_label.config(text=f"[오류] 데이터 파싱 실패: {e}")
            return

        # --- 경로가 없으면 새로 탐색 ---
        if not self.actions:
            self.actions = get_initial_actions()

        # --- 다음 행동 결정 ---
        if not self.actions:
            output_command = 'A'
        else:
            output_command = self.actions.pop(0)
            
            if output_command.endswith(' A'):
                start_pos = find_cell(map_data, START_SYMBOL)
                if start_pos:
                    r, c = start_pos
                    direction = output_command.split(' ')[0]
                    
                    dir_map = {'R': 0, 'D': 1, 'L': 2, 'U': 3}
                    if direction in dir_map:
                        d = dir_map[direction]
                        dr, dc = DIRS[d]
                        nr, nc = r + dr, c + dc

                        if in_range(nr, nc, len(map_data), len(map_data[0])) and map_data[nr][nc] == 'T':
                            # Target is 'T', prioritize normal bomb
                            fire_cmd = None
                            # Check for normal bombs
                            if 'M' in my_allies and len(my_allies['M']) > 2 and int(my_allies['M'][2]) > 0:
                                fire_cmd = f"{direction} F"
                            # Else, check for mega bombs
                            elif 'M' in my_allies and len(my_allies['M']) > 3 and int(my_allies['M'][3]) > 0:
                                fire_cmd = f"{direction} F M"
                            
                            if fire_cmd:
                                output_command = fire_cmd
        self.command_output_label.config(text=f"{output_command}")

        # --- 결정된 행동을 현재 상태에 적용 (시뮬레이션) ---
        self.apply_action(output_command)

        # --- 시뮬레이션 후의 새 상태를 가져와 화면에 업데이트 ---
        new_state_str = get_state_string()
        
        # 1. 왼쪽 입력창 업데이트
        self.state_input_text.delete('1.0', tk.END)
        self.state_input_text.insert('1.0', new_state_str)

        # 2. 오른쪽 정보창 업데이트
        import io
        from contextlib import redirect_stdout
        f = io.StringIO()
        with redirect_stdout(f):
            print_data() # apply_action 이후의 상태로 브리핑
        info_str = f.getvalue()

        self.info_output_text.config(state='normal')
        self.info_output_text.delete('1.0', tk.END)
        self.info_output_text.insert('1.0', info_str)
        self.info_output_text.config(state='disabled')

if __name__ == "__main__":
    root = tk.Tk()
    app = ManualRunnerGUI(root)
    root.mainloop()