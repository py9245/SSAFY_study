﻿"""BattleSSAFY GUI package."""
